True Realistic Driving V by any333
-----------------------------------------------------------------

Important:
-REMOVE ALL PREVIOUS TRUE REALISTIC DRIVING V VERSIONS BEFORE INSTALLING THIS!
-Parameters descriptions in the *.ini!
-Editing handling values in-game by external scripts WILL NOT change RealisticMass physics. You'll have to reload manually in the menu.
-Enhanced native trainer incompatible
-Usage with a custom handling.meta mod highly recommended!
-Menu will only open while in a car
-Teleporting is bugged, as it's impossible to determine when the vehicle is teleported and disable the inertia forces.

------------------------------------------------------

RealisticMass
-Adds inertia forces to your vehicle, tries to simulate the mass found in handling.meta
-GTAV doesn't take mass into account for vehicle physics, this mod tries to mitigate that

Installation/Usage
-Put the .asi and .ini and into your GTA V folder
-See settings in .ini, Game reload required.
-Default keys for menu navigation: UP = L; DOWN = K; ENTER(SHOW MENU) = O

Updates:
https://www.gta5-mods.com/scripts/true-realistic-driving-v-realistic-mass-v0-1-beta

Credits
Modified from: Real Time Handling Editor by ikt