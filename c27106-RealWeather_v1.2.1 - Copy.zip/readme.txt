Have you ever wanted the in-game weather to be the same weather as Los Angeles, CA, New York, NY, or any other place you can think of?
Well that is exactly what this mod does: you select a location, the mod will retrieve the weather from the internet and then set the in-game weather to the retrieved weather.

How to install:
Install Script Hook V by Alexander Blade (http://www.dev-c.com/gtav/scripthookv/).
Copy the "RealWeather.asi" and "RealWeather.ini" files to your GTA V directory.

How to use:
Change the LOCATION within the INI file to whatever city you want, and save. The format of the location has to be CITY, STATE, COUNTRY, or the equivalent for the location. Example: Chicago, IL, USA. If it's not in the correct format openweathermap.org will not find the location.
The mod's default setting is to be enabled on startup, so you don't need to press any buttons, but if you want to disable it then press Right-CTRL + W (by default).

Customizations within the INI file:
Enabled on startup ("ENABLED_ON_STARTUP") (1 means true, 0 means false).
Write debug messages to the RealWeather.log file ("DEBUG") (1 means true, 0 means false).
Get notification when weather is set ("NOTIFY_WHEN_SET_WEATHER") (1 means true, 0 means false).
The location ("LOCATION").
The keys ("HOLD_KEY" and "PRESS_KEY") (use hex codes from https://msdn.microsoft.com/en-us/library/windows/desktop/dd375731(v=vs.85).aspx).
The openweathermap.org API key ("API_KEY").

Notes:
If you get an error related to the API key get your own API key and replace the default.
To get an API key, sign up for openweathermap.org, go to home.openweathermap.org, copy the API key (it will look something like 95e1e267fa5e57d5fc9acd10e91bcebe), and then paste it in the INI file after "API_KEY = ".

Change-log:
v1.2.1:
	Added transition to new weather.
v1.2:
	MANY improvements to the code.
	Open-sourced.
	Switched to INI for settings instead of XML (if you have any previous version installed please remove RealWeather.xml as it's not used anymore).
	Removed separate ASI for debugging and replaced with the DEBUG INI setting.
	Switched to libcurl for getting weather data from the internet.
v1.1:
	Changed VERBOSE_LOGGING XML item to LOG_WHEN_GET_SET_WEATHER.
	Added ability to log URL and response.
	Added ability to get notification when weather is set.
	Added ability to use a personal API key.
	Fix for some possible game crashes.
	Other minor improvements.

Source code: https://github.com/Jitnaught/RealWeather/

Thanks:
Alexander Blade for Script Hook V and helping me out with a problem I had.
Daniel Stenberg for curl.
Lee Thomason for TinyXML-2.
openweathermap.org for providing weather data.